This package allows users to easily access protein files, identify protein-ligand and protein-protein interactions, quantify residues and atoms, easily obtain FASTA sequences, and more.

Full documentation available at https://proteintools.readthedocs.io/en/latest/
